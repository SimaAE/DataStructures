/* This program demonstrates the use of hash tables.

By Sima Elsherif

For MS 549 Data Structures and Testing
Dr. Jill Coddington
University of Advancing Technology*/

#include <iostream>
#include <list>
#include <time.h>

using namespace std;

//Define the Hash Table class
class HT
{
	int numofindex;
	list<int>* hashT;

public:
	HT(int val);
	void insertItem(int ins);
	void deleteItem(int del);
	int hash(int h);
	void display();
};

int HT::hash(int h)
{
	return h % 773;
}


//Create a new instance of the Hash Table class
HT::HT(int val)
{
	this->numofindex = val;
	hashT = new list<int>[numofindex];
}

//Define the function that inserts items into the table
void HT::insertItem(int ins)
{
	int index = hash(ins);
	hashT[index].push_back(ins);
}

//Define the function that deletes items from the table
void HT::deleteItem(int del)
{
	int index = hash(del);

	list <int> ::iterator i;
	for (i = hashT[index].begin(); i != hashT[index].end();	i++)
	{
		if (*i == del)
			break;
	}
	if (i != hashT[index].end())
		hashT[index].erase(i);
}

//Display the contents of the Hash Table
void HT::display()
{
	for (int i = 0; i < numofindex; i++)
	{
		cout << i;
		for (auto x : hashT[i])
			cout << " --> " << x;
		cout << endl;
	}
}

int main()
{
	int values[101];
	int userDelete = 0;

	//Assign random values to array
	for (int i = 1; i < 101; i++)
	{
		values[i] = rand() % 1000 + 1;
	}

	HT h1(773); //Create hash table
	clock_t start, end, duration; //Define clock variables


	start = clock(); //Start timer to measure the insertion process

	//Insert items into hash table
	for (int i = 1; i < 101; i++)
	{
		h1.insertItem(values[i]);
	}

	h1.display(); //Display Hash Table contents

	end = clock(); //End timer

	//Display modified hash table and process duration 
	duration = end - start;
	cout << endl << "It took " << duration << " millisecond(s) to insert into and display the Hash Table." << endl;

	//Ask for user input
	cout << "\n Please enter a number to delete or enter 0 to exit: \n";
	cin >> userDelete;

	start = clock(); //Start timer to measure the insertion process

	h1.deleteItem(userDelete); //Delete item from Hash Table
	h1.display(); //Display Hash Table contents after deletion

	end = clock(); //End timer

	//Display modified hash table and process duration 
	duration = end - start;
	cout << endl << "It took " << duration << " millisecond(s) to delete the requested node and display the Hash Table." << endl;

	return 0;
}


