import networkx
# helper functions to use three of the networkx algorithms
def dijkstra(graph,start,end):
    path = networkx.dijkstra_path(graph,start,end)
    print(f'Dijkstra shortest path from {start} -> {end}: {path}')
def astar(graph,start,end):
    path = networkx.astar_path(graph,start,end)
    print(f'A* shortest path from {start} -> {end}: {path}')
def bfs(graph,start):
    bfs_edges = networkx.bfs_edges(graph,start)
    print(f'Breadth-first search from {start}: {list(bfs_edges)}')
# create empty directional graph
example_graph = networkx.DiGraph()
# directional edges with weights from example graph
example_edges = [
    ('NYC', 'CHI', 4),
    ('CHI', 'NYC', 4),
    ('NYC', 'PHI', 2),
    ('PHI', 'NYC', 2),
    ('NYC', 'CHA', 4),
    ('CHA', 'NYC', 4),
    ('CHI', 'SEA', 6),
    ('SEA', 'CHI', 6),
    ('CHI', 'PHI', 3),
    ('PHI', 'CHI', 3),
    ('CHI', 'HOU', 5),
    ('HOU', 'CHI', 5),
    ('CHI', 'PHO', 6),
    ('PHO', 'CHI', 6),
    ('CHI', 'LA', 7),
    ('LA', 'CHI', 7),
    ('PHI', 'CHA', 3),
    ('CHA', 'PHI', 3),
    ('PHI', 'HOU', 4),
    ('HOU', 'PHI', 4),
    ('PHI', 'PHO', 7),
    ('PHO', 'PHI', 7),
    ('PHI', 'LA', 8),
    ('LA', 'PHI', 8),
    ('CHA', 'HOU', 5),
    ('HOU', 'CHA', 5),
    ('HOU', 'PHO', 3),
    ('PHO', 'HOU', 3),
    ('HOU', 'LA', 5),
    ('LA', 'HOU', 5),
    ('PHO', 'LA', 3),
    ('LA', 'PHO', 3),
    ('PHO', 'SEA', 4),
    ('SEA', 'PHO', 4)
]
# create nodes and graph based on edges with weights
example_graph.add_weighted_edges_from(example_edges)
# shortest path using dijkstra's algorithm
dijkstra(example_graph,'CHA','SEA')
dijkstra(example_graph,'NYC','LA')
# shortest path using a* algorithm
astar(example_graph,'CHA','SEA')
astar(example_graph,'NYC','LA')
# breadth-first sorting, list of possible paths from a starting node
bfs(example_graph,'NYC')
bfs(example_graph,'LA')
# custom graph
custom_graph = networkx.Graph()
# non-directional weighted edges for custom graph based on 'power grid' board game
custom_edges = [
    ('NYC', 'CHI', 4), ('CHI', 'NYC', 4), ('NYC', 'PHI', 2), ('PHI', 'NYC', 2),
    ('NYC', 'CHA', 4), ('CHA', 'NYC', 4), ('CHI', 'SEA', 6), ('SEA', 'CHI', 6),
    ('CHI', 'PHI', 3), ('PHI', 'CHI', 3), ('CHI', 'HOU', 5), ('HOU', 'CHI', 5),
    ('CHI', 'PHO', 6), ('PHO', 'CHI', 6), ('CHI', 'LA', 7), ('LA', 'CHI', 7),
    ('PHI', 'CHA', 3), ('CHA', 'PHI', 3), ('PHI', 'HOU', 4), ('HOU', 'PHI', 4),
    ('PHI', 'PHO', 7), ('PHO', 'PHI', 7), ('PHI', 'LA', 8), ('LA', 'PHI', 8),
    ('CHA', 'HOU', 5), ('HOU', 'CHA', 5), ('HOU', 'PHO', 3), ('PHO', 'HOU', 3),
    ('HOU', 'LA', 5), ('LA', 'HOU', 5), ('PHO', 'LA', 3), ('LA', 'PHO', 3),
    ('PHO', 'SEA', 4), ('SEA', 'PHO', 4)
]
# create nodes and graph based on board game edges with weights
custom_graph.add_weighted_edges_from(custom_edges)
# shortest path using dijkstra's algorithm
dijkstra(custom_graph,'CHI','CHA')
dijkstra(custom_graph,'SEA','HOU')
# shortest path using a* algorithm
astar(custom_graph,'CHI','CHA')
astar(custom_graph,'SEA','HOU')
# breadth-first sorting, list of possible paths from a starting node
bfs(custom_graph,'PHO')
bfs(custom_graph,'PHI')

